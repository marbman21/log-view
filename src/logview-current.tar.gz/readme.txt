###############################################################################
# Copyright 2006, LogView
# URL: http://www.log-view.com
# Email: info@log-view.com
###############################################################################


LogView - File System Log Viewer
################################

This is an exclusive add-on product for cPanel servers running on Linux.

This script provides a graphical interface for cpanel severs, extending WHM features 
which previously needed to be performed using command line instructions. LogView makes 
it simpler with fewer tasks to view system logs.

LogView allows you to easily view logs, and view the content of the logs. 
Since LogView uses a graphical interface it eliminates the need to login using any 
SSH2 programs or any confusing commands.
